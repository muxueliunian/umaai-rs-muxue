#!/usr/bin/env bash
# G2mix1024：**1024 预算对照臂**。与 G2mix 逐项相同，唯一差别是新批用
# 固定窗口 [0,1024) 截断后的数据与标签（training_data/npy_gen2f1024 + labels_gen2f1024）。
# 预登记见 logs/gen2_budget_0914/preregistration.md。
#
# R4 的八组旧数据 + 本轮 gen2 新批，从头训练。
#
# 与 R4 逐项相同的部分：结构 96/4/2/256×2/0.08、优化设置（batch 256、lr/head_lr 5e-4、
# weight_decay 2e-5、cosine warmup 300、末端 0.02）、预算 30000 optimizer steps、
# --no-early-stop、冻结常量取 target/dagger_d_seed1/run.json、初始化种子 1/2/3。
#
# 唯一改变的是数据与划分口径：
#   * 新增 16 个 2048 列导出目录；
#   * 旧八组外挂由实际采样计划补出的完整组合字段（backfill_combo_fields.py）；
#   * 留出集改走 --validation-combos（split_refs_by_combos），清单见
#     target/gen2_train_0914/dev_validation_combos.json；它重放了 R4 的旧划分，
#     并对新批按 (马娘,构成) 分层补足约 10%。
# ❗不使用 --resume：候选必须从头训练，不继承 R4 的优化器状态与学习率日程。
set -e
SEED="$1"
OUT="target/arm_G2mix1024_seed${SEED}"
NEW_ROOT=training_data/npy_gen2f1024
NEW_LABELS=training_data/labels_gen2f1024

ARGS=()
for D in v6ck:v6 ood_half101:ood_half101 dagger_c:dagger_c dagger_d:dagger_d \
         n4096_w1024:n4096_w1024 n1024:n1024 r2roll:r2roll r3roll:r3roll; do
  NPY="training_data/npy_${D%%:*}"
  ARGS+=(--data "$NPY" --labels "training_data/labels_${D##*:}")
  ARGS+=(--combo-fields "$NPY" "training_data/combo_fields_backfill/npy_${D%%:*}.npy")
done
for P in "$NEW_ROOT"/*/; do
  NAME=$(basename "$P")
  ARGS+=(--data "${P%/}" --labels "$NEW_LABELS/$NAME")
done

python scripts/ramen_nn/train.py \
  "${ARGS[@]}" \
  --validation-combos target/gen2_train_0914/dev_validation_combos.json \
  --output-dir "$OUT" \
  --frozen-constants target/dagger_d_seed1/run.json \
  --seed 20260830 --split-seed 20260830 --init-seed "$SEED" \
  --batch-size 256 --lr 5e-4 --head-lr 5e-4 --weight-decay 2e-5 \
  --lr-schedule cosine --lr-warmup-steps 300 --lr-final-factor 0.02 \
  --max-steps 30000 --no-early-stop \
  --token-dim 96 --heads 4 --encoder-blocks 2 --mlp-width 256 --mlp-blocks 2 \
  --dropout 0.08 --attention-kind simple \
  --eval-columns 0 384 --checkpoint-steps 30000
