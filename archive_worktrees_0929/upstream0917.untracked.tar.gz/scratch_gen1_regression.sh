#!/usr/bin/env bash
# 旧空间回归：gen1 默认空间 525 计划 × 16 局，R4 vs G2mix，纯网络配对。
# 预登记见 logs/gen1_regression_0914/preregistration.md。
set -e
OUT=logs/gen1_regression_0914
BIN=./target/release/ramen_space_bench.exe
COMMON=(--runs-per-plan 16 --run-offset 220000 --seed 61444 --trainer nn --no-fingerprint)
for ARM in "A_r4g123:saved_models/arms/ens_R4_g123.onnx" "B_g2mix:saved_models/arms/ens_G2mix_g123.onnx"; do
  NAME=${ARM%%:*}; MODEL=${ARM##*:}
  echo "=== $NAME  $(date +%H:%M:%S)"
  mkdir -p "$OUT/$NAME"
  "$BIN" "${COMMON[@]}" --model "$MODEL" --csv "$OUT/$NAME/games.csv" > "$OUT/$NAME/stdout.log" 2>&1
  tail -9 "$OUT/$NAME/stdout.log"
done
echo REGRESSION_DONE $(date +%H:%M:%S)
