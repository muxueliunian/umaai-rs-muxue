"""新教师 4096 A/B：导出单成员与三成员集成 ONNX，并用**真实新批局面**补一次对拍。

`export_onnx.py` / `export_ensemble_onnx.py` 自带 batch=1/7 的合成输入对拍；本脚本在
那之上再喂真实的新 4096 批 `x` 行（覆盖全部五个阶段里实际出现的阶段），逐元素比较
PyTorch 与 ONNX Runtime 的输出，门槛 1e-4 不下调。
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np
import torch

sys.path.insert(0, str(Path(__file__).resolve().parent / "scripts" / "ramen_nn"))

from data import ValueNormalization  # noqa: E402
from export_ensemble_onnx import EnsembleNetwork, export_ensemble  # noqa: E402
from export_onnx import export_and_verify  # noqa: E402
from model import model_from_checkpoint  # noqa: E402

ARMS = {
    "NT4096_AllHistory": "target/arm_NT4096_AllHistory_seed%d",
    "NT4096_PostPT": "target/arm_NT4096_PostPT_seed%d",
}
THRESHOLD = 1e-4


def real_inputs(count: int, seed: int = 20260916) -> tuple[np.ndarray, dict]:
    """从新批各目录按阶段分层取真实 x 行。"""

    rng = np.random.default_rng(seed)
    rows, meta = [], {}
    dirs = sorted(p for p in Path("training_data/newteacher4096_0914").iterdir() if p.is_dir())
    per = max(1, count // len(dirs))
    for d in dirs:
        x = np.load(d / "x.npy", mmap_mode="r")
        stage = np.asarray(np.load(d / "stage.npy", mmap_mode="r"))
        pick = []
        for s in np.unique(stage):
            idx = np.flatnonzero(stage == s)
            pick.extend(rng.choice(idx, size=min(len(idx), max(1, per // max(1, len(np.unique(stage))))), replace=False).tolist())
        pick = sorted(set(pick))[:per]
        rows.append(np.asarray(x[pick], dtype=np.float32))
        for s in np.unique(stage[pick]):
            meta[int(s)] = meta.get(int(s), 0) + int(np.count_nonzero(stage[pick] == s))
    return np.concatenate(rows, axis=0), meta


def parity(onnx_path: Path, torch_model: torch.nn.Module, x: np.ndarray) -> dict:
    """真实输入下的 PyTorch vs ONNX Runtime 逐元素比较。

    任一侧出现非有限值，或最大绝对误差没有严格小于门槛，一律抛错停下；
    不写出 `passed: false` 再继续往后导出。误差为 NaN 时 `worst < THRESHOLD`
    为假，同样会被下面的判断拦住。
    """

    import onnxruntime as ort

    sess = ort.InferenceSession(str(onnx_path), providers=["CPUExecutionProvider"])
    name = sess.get_inputs()[0].name
    worst = 0.0
    for lo in range(0, len(x), 256):
        block = x[lo:lo + 256]
        with torch.inference_mode():
            ref = torch_model(torch.from_numpy(block)).numpy()
        got = sess.run(None, {name: block})[0]
        for tag, arr in (("PyTorch", ref), ("onnxruntime", got)):
            bad = int(np.count_nonzero(~np.isfinite(arr)))
            if bad:
                raise SystemExit("对拍失败：%s 输出在第 %d 行起的块里有 %d 个非有限值（%s）"
                                 % (tag, lo, bad, onnx_path))
        worst = max(worst, float(np.max(np.abs(ref - got))))
    if not worst < THRESHOLD:
        raise SystemExit("对拍失败：%s 真实输入最大绝对误差 %.6g，未严格小于门槛 %g"
                         % (onnx_path, worst, THRESHOLD))
    return {"rows": int(len(x)), "max_abs_error": worst, "threshold": THRESHOLD,
            "passed": True}


def main() -> None:
    ap = argparse.ArgumentParser(description="导出 A/B 两臂的 ONNX 并补真实局面对拍")
    ap.add_argument("--out", type=Path, required=True, help="汇总 JSON 路径")
    ap.add_argument("--rows", type=int, default=512)
    args = ap.parse_args()

    x, stage_hist = real_inputs(args.rows)
    bad = int(np.count_nonzero(~np.isfinite(x)))
    if bad:
        raise SystemExit("真实对拍输入本身有 %d 个非有限值，停下处理" % bad)
    print("真实对拍输入 %d 行，阶段分布 %s" % (len(x), stage_hist), flush=True)

    summary = {"real_input_rows": int(len(x)), "real_input_stage_hist": stage_hist,
               "threshold": THRESHOLD, "arms": {}}
    for arm, pat in ARMS.items():
        cks = [Path(pat % s) / "step_030000.pt" for s in (1, 2, 3)]
        for p in cks:
            if not p.is_file():
                raise SystemExit("缺少 checkpoint：%s" % p)
        entry = {"members": [str(p).replace("\\", "/") for p in cks], "single": {}, "ensemble": {}}

        for s, p in zip((1, 2, 3), cks):
            out = Path("saved_models/arms/%s_seed%d.onnx" % (arm, s))
            if out.exists():
                raise SystemExit("输出已存在，停下处理：%s" % out)
            rep = export_and_verify(p, out, 13)
            ck = torch.load(p, map_location="cpu", weights_only=False)
            m = model_from_checkpoint(ck, torch.device("cpu")).eval()
            entry["single"]["seed%d" % s] = {
                "onnx": str(out).replace("\\", "/"),
                "synthetic_max_abs_error": rep["max_abs_error"],
                "real_input_parity": parity(out, m, x),
                "operators": rep["operators"], "input_dim": rep["input_dim"], "output_dim": rep["output_dim"],
            }
            print("%s seed%d 单体：合成 %.3g，真实 %.3g" %
                  (arm, s, rep["max_abs_error"], entry["single"]["seed%d" % s]["real_input_parity"]["max_abs_error"]), flush=True)

        ens_out = Path("saved_models/arms/ens_%s_g123.onnx" % arm)
        if ens_out.exists():
            raise SystemExit("输出已存在，停下处理：%s" % ens_out)
        rep = export_ensemble(cks, ens_out, 13)
        cks_loaded = [torch.load(p, map_location="cpu", weights_only=False) for p in cks]
        models = [model_from_checkpoint(c, torch.device("cpu")) for c in cks_loaded]
        norms = [ValueNormalization.from_dict(c["value_normalization"]) for c in cks_loaded]
        ens = EnsembleNetwork(models, [list(n.center) for n in norms], [list(n.scale) for n in norms]).eval()
        entry["ensemble"] = {
            "onnx": str(ens_out).replace("\\", "/"),
            "synthetic_max_abs_error": rep["max_abs_error"],
            "synthetic_by_batch": rep["max_abs_error_by_batch"],
            "real_input_parity": parity(ens_out, ens, x),
            "operators": rep["operators"], "input_dim": rep["input_dim"], "output_dim": rep["output_dim"],
            "rule": rep["rule"], "opset": rep["opset"],
            "members_share_constants": all(n.to_dict() == norms[0].to_dict() for n in norms),
        }
        print("%s 集成：合成 %.3g，真实 %.3g，通过=%s" %
              (arm, rep["max_abs_error"], entry["ensemble"]["real_input_parity"]["max_abs_error"],
               entry["ensemble"]["real_input_parity"]["passed"]), flush=True)
        summary["arms"][arm] = entry

    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(summary, ensure_ascii=False, indent=1), encoding="utf-8")
    print("写出", args.out, flush=True)


if __name__ == "__main__":
    main()
