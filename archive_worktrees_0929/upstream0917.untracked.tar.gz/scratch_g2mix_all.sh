#!/usr/bin/env bash
# 三个初始化种子并行训练。每个进程互相独立（各自的 init_seed 只决定初始化、
# dropout 与 minibatch 顺序），划分与冻结常量完全相同，并行与串行结果一致。
set -e
mkdir -p logs/gen2_train_0914
PIDS=()
for SEED in 1 2 3; do
  D="target/arm_G2mix_seed${SEED}"
  if [ -f "$D/step_030000.pt" ]; then echo "skip seed$SEED"; continue; fi
  echo "=== G2mix seed$SEED 启动 $(date +%H:%M:%S)"
  bash scratch_g2mix.sh "$SEED" > "logs/gen2_train_0914/train_seed${SEED}.log" 2>&1 &
  PIDS+=($!)
done
for P in "${PIDS[@]}"; do wait "$P"; done
echo TRAIN_DONE $(date +%H:%M:%S)
