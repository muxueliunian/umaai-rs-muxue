"""三臂闭环的**诊断性**拆解：五维 / PT / 三年地区选择。

只读既有产物（六组 `games.csv`），不重跑、不重训、不改任何现役配置，
也不覆盖 `report.md` / `preregistration.md` / 原始 CSV。输出写到
`logs/newteacher4096_ab_closedloop_0916/diagnosis/`。

口径来源（全部核对过实际代码，不按字段名猜）：

* 五维 = `Uma::five_status`，**内部数值**。`Uma::add_value` 在每次加算时就
  `.min(five_status_limit)`，因此 CSV 里的值已经是截断后的内部值，不是游戏显示值，
  也不是计分换算值。
* 计分 = `Uma::calc_score()` = `score_parts().total()`，七项之和：
  `skill`（本剧本恒为 510，从不学技能）
  + `pt` = `(total_pt() as f32 * pt_score_rate) as i32`，`pt_score_rate = 2.0`
  + Σ `status_final_score(min(five_status[i], limit[i]))`，**查表非线性**，
    表长 3399、末位饱和。所以原始属性差 ≠ 得分贡献差。
* `total_pt()` = `floor(skill_pt + total_hints * 6.5)`。`total_hints` **不在 CSV**，
  但可从「分数 − 510 − Σ属性分」的残差反解（本脚本会逐局验证反解自洽）。
* `skill_pt` 在拉面剧本里只增不减（不学技能），因此等于累计获得，不是可消费余额。
* `scenario_pt_y*` 是**拉面剧本 PT**，与 `skill_pt` 完全无关，**不进计分**，
  只决定 `ramen_pt_effect` / `region_bonus` 档位；年末 RMJ 结算归零前快照。
* 地区：每年选 **3 个**，候选来自 `rules::REGION_RANGES` = [(0,4),(5,9),(10,19)]，
  即 C(5,3)=10 / C(5,3)=10 / C(10,3)=120；`get_region_combinations` 产出升序三元组。
  名称取自 `gamedata/scenario_ramen.json` 的 `ramen_region_effect[i].name`。

所有校验失败一律 `SystemExit`，不静默容错、不丢样本。
"""

from __future__ import annotations

import csv
import json
from collections import Counter
from itertools import combinations
from pathlib import Path

import numpy as np

ROOT = Path(".")
OUT = ROOT / "logs/newteacher4096_ab_closedloop_0916"
DIAG = OUT / "diagnosis"
ARMS = ["G2mix", "AllHistory", "PostPT"]
PAIRS = [("主：PostPT−AllHistory", "AllHistory", "PostPT"),
         ("次：AllHistory−G2mix", "G2mix", "AllHistory"),
         ("次：PostPT−G2mix", "G2mix", "PostPT")]
FIVE = ["speed", "stamina", "power", "guts", "wisdom"]
FIVE_CN = {"speed": "速度", "stamina": "耐力", "power": "力量", "guts": "根性", "wisdom": "智力"}
NEW_SHAPE = "2速1力1根1智1友"
UMA_FOCUS = "113101"
REGION_RANGES = [(0, 4), (5, 9), (10, 19)]
SKILL_SCORE_CONST = 510          # Uma::new 写死 510，拉面剧本无任何写入点
PT_SCORE_RATE = 2.0              # gamedata/constants.json
HINT_PT_RATE = 6.5               # gamedata/constants.json


# ---------------------------------------------------------------- 静态数据

def load_constants() -> tuple[np.ndarray, list[str]]:
    """属性→最终得分查表，以及 20 个地区的名字。"""

    cons = json.loads((ROOT / "gamedata/constants.json").read_text(encoding="utf-8"))
    if abs(cons["pt_score_rate"] - PT_SCORE_RATE) > 0 or abs(cons["hint_pt_rate"] - HINT_PT_RATE) > 0:
        raise SystemExit("constants.json 的 pt_score_rate / hint_pt_rate 与脚本假设不符，停下处理")
    table = np.asarray(cons["five_status_final_score"], dtype=np.int64)
    ramen = json.loads((ROOT / "gamedata/scenario_ramen.json").read_text(encoding="utf-8"))
    names = [e["name"] for e in ramen["ramen_region_effect"]]
    for i, e in enumerate(ramen["ramen_region_effect"]):
        if int(e["id"]) != i:
            raise SystemExit("ramen_region_effect 下标与 id 不一致（%d vs %s），地区编号映射不可信" % (i, e["id"]))
    if len(names) != 20:
        raise SystemExit("地区数不是 20：%d" % len(names))
    return table, names


def region_label(names: list[str], rid: int) -> str:
    return "%d %s" % (rid, names[rid])


def combo_label(names: list[str], combo: tuple[int, ...]) -> str:
    return "+".join(region_label(names, r) for r in combo)


# ---------------------------------------------------------------- 计划表

def plans_main() -> list[dict]:
    plans = json.loads((ROOT / "scripts/collect/formal2048_0914/holdout.json").read_text(encoding="utf-8"))["plans"]
    return [{"uma": str(p["fields"][0]), "plan": int(p["plan"])} for p in plans]


def plans_gen1() -> list[dict]:
    out = []
    for line in (ROOT / "target/gen2_train_0914/plan_dump.txt").read_text(encoding="utf-8").splitlines():
        if line.startswith("GEN1PLAN "):
            parts = line.split()
            out.append({"uma": parts[2], "plan": int(parts[1]), "shape": parts[4]})
    return out


# ---------------------------------------------------------------- 读取与派生

def load_arm(panel: str, arm: str, n_plans: int, k: int, table: np.ndarray) -> dict:
    """读一臂的逐局 CSV，还原 [n_plans, k] 矩阵并派生计分分解。"""

    path = OUT / panel / arm / "games.csv"
    rows = list(csv.DictReader(path.open(encoding="utf-8")))
    if len(rows) != n_plans * k:
        raise SystemExit("%s 行数 %d ≠ %d×%d" % (path, len(rows), n_plans, k))

    def ints(name: str) -> np.ndarray:
        vals = []
        for i, r in enumerate(rows):
            cell = r.get(name)
            if cell is None or cell == "":
                raise SystemExit("%s 第 %d 行的 %s 为空，缺失值不补齐" % (path, i + 2, name))
            try:
                vals.append(int(cell))
            except ValueError:
                raise SystemExit("%s 第 %d 行的 %s 不是整数：%r" % (path, i + 2, name, cell))
        return np.asarray(vals, dtype=np.int64).reshape(n_plans, k)

    d = {"build": np.asarray([r["build"] for r in rows], dtype=object).reshape(n_plans, k),
         "seed": np.asarray([r["seed"] for r in rows], dtype=object).reshape(n_plans, k)}
    for name in ("score", "skill_pt", "rmj_ok", "free_race_ok", *FIVE,
                 *["scenario_pt_y%d" % y for y in (1, 2, 3)],
                 *["eat_count_y%d" % y for y in (1, 2, 3)]):
        d[name] = ints(name)
    ms = []
    for i, r in enumerate(rows):
        v = float(r["elapsed_ms"])
        if not np.isfinite(v):
            raise SystemExit("%s 第 %d 行的 elapsed_ms 非有限：%r" % (path, i + 2, r["elapsed_ms"]))
        ms.append(v)
    d["elapsed_ms"] = np.asarray(ms, dtype=np.float64).reshape(n_plans, k)

    # 地区：解析 + 合法性校验（三个 id、互异、升序、落在当年候选范围内）
    regions = np.zeros((3, n_plans * k, 3), dtype=np.int64)
    for y in range(3):
        lo, hi = REGION_RANGES[y]
        for i, r in enumerate(rows):
            cell = r["region_y%d" % (y + 1)]
            parts = cell.split("/")
            if len(parts) != 3:
                raise SystemExit("%s 第 %d 行 region_y%d 不是 3 个 id：%r" % (path, i + 2, y + 1, cell))
            try:
                ids = [int(p) for p in parts]
            except ValueError:
                raise SystemExit("%s 第 %d 行 region_y%d 含非整数：%r" % (path, i + 2, y + 1, cell))
            if len(set(ids)) != 3:
                raise SystemExit("%s 第 %d 行 region_y%d 有重复地区：%r" % (path, i + 2, y + 1, cell))
            if ids != sorted(ids):
                raise SystemExit("%s 第 %d 行 region_y%d 不是升序：%r" % (path, i + 2, y + 1, cell))
            if not all(lo <= v <= hi for v in ids):
                raise SystemExit("%s 第 %d 行 region_y%d 越出候选范围 %d..%d：%r"
                                 % (path, i + 2, y + 1, lo, hi, cell))
            regions[y, i] = ids
    d["regions"] = regions.reshape(3, n_plans, k, 3)

    # 计分分解：严格照 Uma::score_parts()
    five = np.stack([d[n] for n in FIVE], axis=-1)              # [p, k, 5]
    if (five < 0).any():
        raise SystemExit("%s 出现负的五维值" % path)
    idx = np.minimum(five, len(table) - 1)
    status_score = table[idx]                                    # [p, k, 5]
    for j, name in enumerate(FIVE):
        d["score_" + name] = status_score[..., j].astype(np.int64)
    d["score_five_sum"] = status_score.sum(axis=-1).astype(np.int64)
    resid = d["score"] - SKILL_SCORE_CONST - d["score_five_sum"]
    if (resid % 2 != 0).any():
        raise SystemExit("%s：分数残差出现奇数，PT 项 = 2×total_pt 的假设不成立" % path)
    d["score_pt"] = resid
    total_pt = resid // 2
    d["total_pt"] = total_pt
    hint_pt = total_pt - d["skill_pt"]
    if (hint_pt < 0).any():
        raise SystemExit("%s：反解出的 hint 折算 PT 为负，口径不成立" % path)
    h0 = (hint_pt * 2) // 13
    hits0 = np.floor(HINT_PT_RATE * h0).astype(np.int64) == hint_pt
    hints = np.where(hits0, h0, h0 + 1)
    if not (np.floor(HINT_PT_RATE * hints).astype(np.int64) == hint_pt).all():
        raise SystemExit("%s：total_hints 反解不自洽，计分分解不可信" % path)
    if (hints < 21).any():
        raise SystemExit("%s：反解出的 total_hints 小于初始值 21" % path)
    d["total_hints"] = hints
    d["hint_pt"] = hint_pt
    # 自洽：七分量之和必须逐局等于 score
    rebuilt = SKILL_SCORE_CONST + d["score_pt"] + d["score_five_sum"]
    if not np.array_equal(rebuilt, d["score"]):
        raise SystemExit("%s：分解之和与原分数不等" % path)

    d["scenario_pt_sum"] = sum(d["scenario_pt_y%d" % y] for y in (1, 2, 3))
    d["eat_count_sum"] = sum(d["eat_count_y%d" % y] for y in (1, 2, 3))
    d["fail"] = (d["free_race_ok"] == 0)
    return d


def check_pairing(panel: str, data: dict, plans: list[dict], n: int, k: int) -> dict:
    base = data[ARMS[0]]
    for arm in ARMS[1:]:
        if not np.array_equal(base["seed"], data[arm]["seed"]):
            raise SystemExit("%s：%s 与 %s 的世界种子不是逐局相同" % (panel, ARMS[0], arm))
        if not np.array_equal(base["build"], data[arm]["build"]):
            raise SystemExit("%s：%s 与 %s 的构成序列不同" % (panel, ARMS[0], arm))
    for i in range(n):
        if len(set(base["build"][i])) != 1:
            raise SystemExit("%s：第 %d 个计划块内构成不唯一" % (panel, i))
    if "shape" in plans[0]:
        bad = [i for i, p in enumerate(plans) if p["shape"] != base["build"][i][0]]
        if bad:
            raise SystemExit("%s：CSV 块序与计划表不符，%d 个计划对不上" % (panel, len(bad)))
    uniq = len(set(base["seed"].ravel().tolist()))
    if uniq != n * k:
        raise SystemExit("%s：唯一世界 %d ≠ 局数 %d" % (panel, uniq, n * k))
    return {"plans": n, "runs_per_plan": k, "games_per_arm": n * k, "unique_worlds": uniq,
            "三臂世界种子逐局相同": True, "块序与计划表一致": True}


# ---------------------------------------------------------------- 统计

def describe(x: np.ndarray) -> dict:
    v = x.astype(np.float64).ravel()
    if not np.isfinite(v).all():
        raise SystemExit("描述统计遇到非有限值")
    return {"mean": float(v.mean()), "sd": float(v.std(ddof=1)),
            "p10": float(np.percentile(v, 10)), "p50": float(np.percentile(v, 50)),
            "p90": float(np.percentile(v, 90))}


def paired(a: np.ndarray, b: np.ndarray) -> dict:
    """b − a：逐局配对、按计划聚类，±1.96 SE。"""

    d = (b - a).astype(np.float64)
    per_plan = d.mean(axis=1)
    n = len(per_plan)
    mean = float(per_plan.mean())
    se = float(per_plan.std(ddof=1) / np.sqrt(n)) if n > 1 else float("nan")
    return {"plans": int(n), "games": int(d.size), "mean_diff": mean, "cluster_se": se,
            "ci95": [mean - 1.96 * se, mean + 1.96 * se],
            "excludes_zero": bool(np.isfinite(se) and (mean - 1.96 * se) * (mean + 1.96 * se) > 0),
            "games_win": int((d > 0).sum()), "games_tie": int((d == 0).sum()),
            "games_loss": int((d < 0).sum()),
            "plans_win": int((per_plan > 0).sum()), "plans_loss": int((per_plan < 0).sum())}


METRICS = ["score", *FIVE, "skill_pt", "total_pt", "total_hints",
           "scenario_pt_y1", "scenario_pt_y2", "scenario_pt_y3", "scenario_pt_sum",
           "score_five_sum", "score_pt",
           *["score_" + n for n in FIVE], "eat_count_sum", "rmj_ok"]

# 五维上限：limit_base(scenario_ramen) + 继承上限增量。继承上限
# `InheritInfo::inherit_limit` 不吃 rng，恒为 blue_count*5.33 → [79,0,0,0,15]，
# 开局一次 + 局中继承事件若干次。耐/力/根的 blue_count 为 0，上限**恒定**；
# 速/智的上限取决于局中继承事件次数，CSV 未记录，此处只按观测到的最高档判定。
HARD_CAP = {"stamina": 2400, "power": 2200, "guts": 2200}
SOFT_CAP = {"speed": [3179, 3258, 3337], "wisdom": [2415, 2430, 2445]}


def cap_stats(data: dict, mask: np.ndarray) -> dict:
    out = {}
    for arm in ARMS:
        e = {}
        for name, cap in HARD_CAP.items():
            v = data[arm][name][mask]
            if (v > cap).any():
                raise SystemExit("%s 的 %s 超过恒定上限 %d，上限推导有误" % (arm, name, cap))
            e[name] = {"cap": cap, "cap_hit": int((v == cap).sum()), "games": int(v.size),
                       "rate": float((v == cap).mean())}
        for name, caps in SOFT_CAP.items():
            v = data[arm][name][mask]
            top = caps[-1]
            if (v > top).any():
                raise SystemExit("%s 的 %s 超过最高可能上限 %d" % (arm, name, top))
            e[name] = {"cap_candidates": caps, "max_cap": top,
                       "at_max_cap": int((v == top).sum()), "games": int(v.size),
                       "rate_at_max_cap": float((v == top).mean()),
                       "above_second_cap": int((v > caps[-2]).sum())}
        out[arm] = e
    return out


# ---------------------------------------------------------------- 地区

def region_panel(data: dict, mask: np.ndarray, names: list[str]) -> dict:
    """三年地区分布 + 三臂一致性。mask 选计划。"""

    out = {}
    for y in range(3):
        lo, hi = REGION_RANGES[y]
        legal_ids = list(range(lo, hi + 1))
        legal_combos = [tuple(c) for c in combinations(legal_ids, 3)]
        sel = {arm: data[arm]["regions"][y][mask].reshape(-1, 3) for arm in ARMS}
        games = sel[ARMS[0]].shape[0]
        year = {"year": y + 1, "turn": [2, 23, 47][y],
                "legal_region_ids": legal_ids, "legal_combos": len(legal_combos),
                "games_per_arm": int(games), "records": int(games), "missing": 0, "arms": {}}
        for arm in ARMS:
            s = sel[arm]
            marg = Counter(s.ravel().tolist())
            if sum(marg.values()) != games * 3:
                raise SystemExit("第 %d 年 %s 的地区边际计数合计不是 3×局数" % (y + 1, arm))
            combos = Counter(tuple(r) for r in s.tolist())
            if sum(combos.values()) != games:
                raise SystemExit("第 %d 年 %s 的组合计数合计不是局数" % (y + 1, arm))
            ranked = combos.most_common()
            marg_share = {region_label(names, r): marg.get(r, 0) / games for r in legal_ids}
            if abs(sum(marg_share.values()) - 3.0) > 1e-9:
                raise SystemExit("第 %d 年 %s 的边际比例合计不是 300%%" % (y + 1, arm))
            combo_share = [(combo_label(names, c), n, n / games) for c, n in ranked]
            if abs(sum(v for _, _, v in combo_share) - 1.0) > 1e-9:
                raise SystemExit("第 %d 年 %s 的组合比例合计不是 100%%" % (y + 1, arm))
            year["arms"][arm] = {
                "marginal_counts": {region_label(names, r): int(marg.get(r, 0)) for r in legal_ids},
                "marginal_share": marg_share,
                "distinct_combos": len(ranked),
                "top1_share": ranked[0][1] / games,
                "top3_share": sum(n for _, n in ranked[:3]) / games,
                "top_combos": [{"combo": lbl, "games": int(n), "share": sh}
                               for lbl, n, sh in combo_share[:8]]}
        # 三臂一致性
        a, b, g = sel["AllHistory"], sel["PostPT"], sel["G2mix"]
        all_same = int(np.sum([tuple(x) == tuple(y_) == tuple(z)
                               for x, y_, z in zip(g.tolist(), a.tolist(), b.tolist())]))
        year["three_arms_identical"] = {"games": all_same, "share": all_same / games}
        year["pairwise"] = {}
        for tag, (p, q) in {"AllHistory vs G2mix": (g, a), "PostPT vs AllHistory": (a, b),
                            "PostPT vs G2mix": (g, b)}.items():
            shared = np.asarray([len(set(x) & set(y_)) for x, y_ in zip(p.tolist(), q.tolist())])
            same = int((shared == 3).sum())
            moves = Counter((combo_label(names, tuple(x)), combo_label(names, tuple(y_)))
                            for x, y_ in zip(p.tolist(), q.tolist()) if tuple(x) != tuple(y_))
            year["pairwise"][tag] = {
                "identical_games": same, "identical_share": same / games,
                "shared_region_count": {str(c): int((shared == c).sum()) for c in (0, 1, 2, 3)},
                "shared_region_share": {str(c): float((shared == c).mean()) for c in (0, 1, 2, 3)},
                "top_switches": [{"from": f, "to": t, "games": int(n), "share": n / games}
                                 for (f, t), n in moves.most_common(5)]}
        out["Y%d" % (y + 1)] = year
    return out


# ---------------------------------------------------------------- 单元格

def by_baseline_decile(data: dict, mask: np.ndarray) -> dict:
    """按**基线臂**的分数十分位分桶，看配对增益落在分布的哪一段。

    分桶变量是基线臂自己的分数，不是配对差，因此不会因为「挑差值大的格」产生选择偏倚；
    但仍属探索性诊断：基线分数本身带噪，分桶会有回归到均值的成分。
    """

    out = {}
    for tag, lo, hi in PAIRS:
        a = data[lo]["score"][mask].astype(np.float64)
        b = data[hi]["score"][mask].astype(np.float64)
        edges = np.percentile(a.ravel(), np.arange(10, 100, 10))
        bucket = np.digitize(a, edges)                      # [plans, k] → 0..9
        rows = []
        for q in range(10):
            sel = bucket == q
            if not sel.any():
                raise SystemExit("%s 的第 %d 个十分位桶为空" % (tag, q))
            d = b - a
            per_plan = [d[i][sel[i]].mean() for i in range(d.shape[0]) if sel[i].any()]
            per_plan = np.asarray(per_plan, dtype=np.float64)
            n = len(per_plan)
            mean = float(per_plan.mean())
            se = float(per_plan.std(ddof=1) / np.sqrt(n)) if n > 1 else float("nan")
            rows.append({"decile": q + 1, "games": int(sel.sum()), "plans": int(n),
                         "baseline_mean": float(a[sel].mean()), "mean_diff": mean,
                         "cluster_se": se, "ci95": [mean - 1.96 * se, mean + 1.96 * se]})
        out[tag] = rows
    return out


def quantile_shift(data: dict, mask: np.ndarray) -> dict:
    """**边际**分数分位数（不配对、不按基线分桶），用来回答「增益落在分布哪一段」。

    这是相对 [`by_baseline_decile`] 更可信的口径：后者按基线臂分数分桶，
    即使两臂完全等价、只差噪声，也会机械地产生「低分桶为正、高分桶为负」的单调形状
    （回归到均值）。分位数差没有这个伪影，代价是不再配对。
    """

    qs = [5, 10, 25, 50, 75, 90, 95]
    out = {"quantiles": qs, "arms": {}}
    for arm in ARMS:
        out["arms"][arm] = [float(v) for v in np.percentile(data[arm]["score"][mask].astype(np.float64), qs)]
    out["diff"] = {tag: [out["arms"][hi][i] - out["arms"][lo][i] for i in range(len(qs))]
                   for tag, lo, hi in PAIRS}
    return out


def low_tail(data: dict, mask: np.ndarray) -> dict:
    """低分局占比：阈值取三臂合并后的 10 / 25 分位，三臂共用同一阈值。"""

    pool = np.concatenate([data[a]["score"][mask].ravel() for a in ARMS]).astype(np.float64)
    out = {}
    for name, pct in (("p10_pooled", 10), ("p25_pooled", 25)):
        thr = float(np.percentile(pool, pct))
        out[name] = {"threshold": thr,
                     "share_below": {a: float((data[a]["score"][mask] < thr).mean()) for a in ARMS}}
    return out


def cell(data: dict, mask: np.ndarray, names: list[str], with_regions: bool = True) -> dict:
    out = {"plans": int(mask.sum()),
           "games_per_arm": int(mask.sum() * data[ARMS[0]]["score"].shape[1]),
           "arms": {}, "paired": {}}
    for arm in ARMS:
        e = {"fail_games": int(data[arm]["fail"][mask].sum()),
             "ms_per_game": float(data[arm]["elapsed_ms"][mask].mean())}
        for m in METRICS:
            e[m] = describe(data[arm][m][mask])
        out["arms"][arm] = e
    for tag, lo, hi in PAIRS:
        out["paired"][tag] = {m: paired(data[lo][m][mask], data[hi][m][mask]) for m in METRICS}
    out["caps"] = cap_stats(data, mask)
    out["score_by_baseline_decile"] = by_baseline_decile(data, mask)
    out["low_tail"] = low_tail(data, mask)
    out["quantile_shift"] = quantile_shift(data, mask)
    if with_regions:
        out["regions"] = region_panel(data, mask, names)
    return out


def main() -> None:
    table, names = load_constants()
    DIAG.mkdir(parents=True, exist_ok=True)
    result = {"说明": "三臂闭环的诊断性拆解；只读既有产物，不重跑、不改现役配置",
              "原报告": (OUT / "report.md").as_posix(),
              "口径": {
                  "五维": "Uma::five_status 内部数值（加算时已 .min(limit) 截断）；非显示值、非计分换算值",
                  "计分": "calc_score = 510(skill，本剧本恒定) + 2×total_pt + Σ status_final_score(五维)，查表非线性",
                  "total_pt": "floor(skill_pt + total_hints×6.5)；total_hints 不在 CSV，由分数残差反解并逐局验证",
                  "skill_pt": "技能点；拉面剧本从不消费，等于累计获得",
                  "scenario_pt_y*": "拉面剧本 PT，年末 RMJ 归零前快照；不进计分，只决定档位",
                  "地区": "每年选 3 个；候选 Y1=0..4 / Y2=5..9 / Y3=10..19；名称取自 scenario_ramen.json"},
              "panels": {}}

    for panel, plans, k in (("main_holdout250", plans_main(), 16),
                            ("gen1_regression525", plans_gen1(), 8)):
        n = len(plans)
        data = {arm: load_arm(panel, arm, n, k, table) for arm in ARMS}
        integrity = check_pairing(panel, data, plans, n, k)
        print("[%s] 完整性通过：%s" % (panel, integrity), flush=True)

        uma = np.asarray([p["uma"] for p in plans], dtype=object)
        build = data[ARMS[0]]["build"][:, 0]
        entry = {"integrity": integrity, "overall": cell(data, np.ones(n, dtype=bool), names),
                 "prespecified": {}}
        if (build == NEW_SHAPE).any():
            entry["prespecified"]["新构成 " + NEW_SHAPE] = cell(data, build == NEW_SHAPE, names)
        if (uma == UMA_FOCUS).any():
            entry["prespecified"]["马娘 " + UMA_FOCUS] = cell(data, uma == UMA_FOCUS, names)
        entry["by_shape"] = {b: cell(data, build == b, names)
                             for b in sorted(set(build.tolist()))}
        result["panels"][panel] = entry

        o = entry["overall"]
        print("  总体均分：" + "  ".join("%s %.0f" % (a, o["arms"][a]["score"]["mean"]) for a in ARMS))
        for tag, _, _ in PAIRS:
            d = o["paired"][tag]["score"]
            print("    %-22s score %+8.1f [%+8.1f,%+8.1f]" %
                  (tag, d["mean_diff"], d["ci95"][0], d["ci95"][1]))
        print(flush=True)

    path = DIAG / "diag_result.json"
    path.write_text(json.dumps(result, ensure_ascii=False, indent=1), encoding="utf-8")
    print("写出", path)


if __name__ == "__main__":
    main()
