"""新教师 4096 A/B 三臂闭环的配对分析。

口径见 `logs/newteacher4096_ab_closedloop_0916/preregistration.md` §5：
逐 (计划, 局号) 配对求差，按组合（计划）聚类算标准误，区间 ±1.96 SE。
失败局不剔除；子组只报预登记里事前定义的那两个，其余按马娘 / 构成的分解只作背景。

行序假设：`ramen_space_bench` 按计划顺序、每计划连跑 `runs_per_plan` 局写 CSV。
本脚本对它做三重校验——块内构成唯一、块顺序与计划表逐项相同、三臂世界种子逐局相同，
任一不成立就停下，不做静默容错。
"""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import numpy as np

OUT = Path("logs/newteacher4096_ab_closedloop_0916")
ARMS = ["G2mix", "AllHistory", "PostPT"]
NEW_SHAPE = "2速1力1根1智1友"   # gen2_v1 有、第一代空间没有的唯一构成
UMA_FOCUS = "113101"
KEYS = ("主比较 PostPT-AllHistory", "次比较 AllHistory-G2mix", "次比较 PostPT-G2mix")


def plans_main() -> list[dict]:
    plans = json.loads(Path("scripts/collect/formal2048_0914/holdout.json").read_text(encoding="utf-8"))["plans"]
    return [{"uma": str(p["fields"][0]), "plan": int(p["plan"])} for p in plans]


def plans_gen1() -> list[dict]:
    out = []
    for line in Path("target/gen2_train_0914/plan_dump.txt").read_text(encoding="utf-8").splitlines():
        if line.startswith("GEN1PLAN "):
            parts = line.split()
            out.append({"uma": parts[2], "plan": int(parts[1]), "shape": parts[4]})
    return out


def load(panel: str, arm: str, n_plans: int, k: int) -> dict:
    """读一臂的逐局 CSV，还原成 [n_plans, k] 的矩阵。"""

    rows = list(csv.DictReader((OUT / panel / arm / "games.csv").open(encoding="utf-8")))
    if len(rows) != n_plans * k:
        raise SystemExit("%s/%s 行数 %d ≠ %d×%d" % (panel, arm, len(rows), n_plans, k))
    col = lambda name, cast: np.array([cast(r[name]) for r in rows], dtype=object if cast is str else None).reshape(n_plans, k)
    build = col("build", str)
    if any(len(set(build[i])) != 1 for i in range(n_plans)):
        raise SystemExit("%s/%s 的计划块内构成不唯一，行序假设不成立" % (panel, arm))
    return {"score": col("score", float).astype(np.float64),
            "seed": col("seed", str),
            "build": build[:, 0],
            "fail": col("free_race_ok", lambda v: int(v) == 0).astype(bool),
            "ms": col("elapsed_ms", float).astype(np.float64)}


def paired(a: np.ndarray, b: np.ndarray, mask: np.ndarray) -> dict:
    """b − a 的按组合聚类统计；mask 选计划。"""

    d = (b - a)[mask]
    per_plan = d.mean(axis=1)
    n = len(per_plan)
    mean = float(per_plan.mean())
    se = float(per_plan.std(ddof=1) / np.sqrt(n)) if n > 1 else float("nan")
    return {"plans": int(n), "games": int(d.size), "mean_diff": mean,
            "cluster_se": se, "ci95": [mean - 1.96 * se, mean + 1.96 * se],
            "plans_positive": int((per_plan > 0).sum()),
            "plans_negative": int((per_plan < 0).sum()),
            "plans_zero": int((per_plan == 0).sum())}


def cell(data: dict, mask: np.ndarray) -> dict:
    out = {"plans": int(mask.sum()), "games": int(mask.sum() * data[ARMS[0]]["score"].shape[1])}
    for arm in ARMS:
        s = data[arm]["score"][mask]
        out[arm] = {"mean": float(s.mean()), "sd": float(s.std(ddof=1)),
                    "fail_games": int(data[arm]["fail"][mask].sum()),
                    "ms_per_game": float(data[arm]["ms"][mask].mean())}
    out[KEYS[0]] = paired(data["AllHistory"]["score"], data["PostPT"]["score"], mask)
    out[KEYS[1]] = paired(data["G2mix"]["score"], data["AllHistory"]["score"], mask)
    out[KEYS[2]] = paired(data["G2mix"]["score"], data["PostPT"]["score"], mask)
    return out


def run_panel(panel: str, plans: list[dict], k: int) -> dict:
    n = len(plans)
    data = {arm: load(panel, arm, n, k) for arm in ARMS}

    base = data[ARMS[0]]
    for arm in ARMS[1:]:
        if not np.array_equal(base["seed"], data[arm]["seed"]):
            raise SystemExit("%s：%s 与 %s 的世界种子不是逐局相同，配对不成立" % (panel, ARMS[0], arm))
        if not np.array_equal(base["build"], data[arm]["build"]):
            raise SystemExit("%s：%s 与 %s 的构成序列不同" % (panel, ARMS[0], arm))
    if "shape" in plans[0]:
        bad = [i for i, p in enumerate(plans) if p["shape"] != base["build"][i]]
        if bad:
            raise SystemExit("%s：CSV 块序与计划表构成不符，%d 个计划对不上" % (panel, len(bad)))
    uniq = len(set(base["seed"].ravel().tolist()))
    if uniq != n * k:
        raise SystemExit("%s：唯一世界只有 %d 个，少于 %d 局，世界有重复" % (panel, uniq, n * k))
    print("[%s] 配对完整性通过：%d 计划 × %d 局，三臂世界种子逐局相同，唯一世界 %d 个"
          % (panel, n, k, uniq), flush=True)

    uma = np.array([p["uma"] for p in plans], dtype=object)
    build = base["build"]

    res = {"plans": n, "runs_per_plan": k, "unique_worlds": uniq,
           "overall": cell(data, np.ones(n, dtype=bool)), "prespecified": {}}
    if (build == NEW_SHAPE).any():
        res["prespecified"]["新构成 " + NEW_SHAPE] = cell(data, build == NEW_SHAPE)
    if (uma == UMA_FOCUS).any():
        res["prespecified"]["马娘 " + UMA_FOCUS] = cell(data, uma == UMA_FOCUS)
    res["by_uma"] = {u: cell(data, uma == u) for u in sorted(set(uma.tolist()))}
    res["by_shape"] = {b: cell(data, build == b) for b in sorted(set(build.tolist()))}
    return res


def show(tag: str, c: dict) -> None:
    print("  %-28s n=%5d  %s" % (tag, c["games"],
          "  ".join("%s %.0f" % (a, c[a]["mean"]) for a in ARMS)))
    for key in KEYS:
        d = c[key]
        verdict = "不含零" if d["ci95"][0] * d["ci95"][1] > 0 else "跨零"
        print("      %-26s %+8.1f [%+8.1f,%+8.1f] %s  计划 %d 正 / %d 负"
              % (key, d["mean_diff"], d["ci95"][0], d["ci95"][1], verdict,
                 d["plans_positive"], d["plans_negative"]))


def main() -> None:
    ap = argparse.ArgumentParser(description="三臂闭环配对分析")
    ap.add_argument("--out", type=Path, default=OUT / "closedloop_result.json")
    args = ap.parse_args()

    result = {"预登记": (OUT / "preregistration.md").as_posix(),
              "冻结输入": (OUT / "frozen_inputs.json").as_posix(),
              "口径": "逐 (计划, 局号) 配对；按计划聚类，区间 ±1.96 SE；失败局不剔除",
              "panels": {}}
    for panel, plans, k in (("main_holdout250", plans_main(), 16),
                            ("gen1_regression525", plans_gen1(), 8)):
        r = run_panel(panel, plans, k)
        result["panels"][panel] = r
        print("[%s] 总体" % panel)
        show("overall", r["overall"])
        for tag, c in r["prespecified"].items():
            show(tag, c)
        print(flush=True)

    args.out.write_text(json.dumps(result, ensure_ascii=False, indent=1), encoding="utf-8")
    print("写出", args.out)


if __name__ == "__main__":
    main()
