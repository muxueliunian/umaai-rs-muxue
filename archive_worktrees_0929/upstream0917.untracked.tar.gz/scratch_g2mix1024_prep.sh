#!/usr/bin/env bash
# 1024 预算对照臂的数据准备：把本轮 16 个 2048 列目录按固定窗口 [0,1024) 截断，
# 再用**同一份标签配方**重新生成标签。
#
# 为什么这样能保住 CRN：采集时录的是**有序** rollout，第 k 列在同一个根内对所有候选
# 都是同一个随机世界。固定窗口 [0,1024) 对所有候选、所有根一致，所以截断后仍是配对的。
# ❗cand_n / cand_mean / cand_stdev 是对全部列求的汇总量，truncate_rollouts.py 会一并重算。
set -e
SRC=target/acceptance_gen2_0914/full/npy/npy
DATA=training_data/npy_gen2f1024
LAB=training_data/labels_gen2f1024
mkdir -p "$DATA" "$LAB" logs/gen2_budget_0914
for P in "$SRC"/*/; do
  NAME=$(basename "$P")
  if [ ! -f "$DATA/$NAME/meta.json" ]; then
    echo "=== 截断 $NAME $(date +%H:%M:%S)"
    python scripts/ramen_nn/truncate_rollouts.py --source "${P%/}" --output "$DATA/$NAME" --width 1024 \
      > "logs/gen2_budget_0914/truncate_${NAME}.log" 2>&1
  fi
  if [ ! -f "$LAB/$NAME/labels.json" ]; then
    echo "=== 标签 $NAME $(date +%H:%M:%S)"
    python scripts/ramen_nn/labels.py --input "$DATA/$NAME" --output "$LAB/$NAME" \
      > "logs/gen2_budget_0914/labels_${NAME}.log" 2>&1
  fi
done
echo PREP_DONE $(date +%H:%M:%S)
