#!/usr/bin/env bash
# 预算对照闭环：1024 臂 vs 2048 臂（G2mix），两块面板，全新世界号段。
# 预登记见 logs/gen2_budget_0914/preregistration.md。主比较 = gen2 250 组合面板。
set -e
OUT=logs/gen2_budget_0914
BIN=./target/release/ramen_space_bench.exe
run () { # $1 目录名  $2 模型  $3... 额外参数
  local NAME=$1 MODEL=$2; shift 2
  echo "=== $NAME  $(date +%H:%M:%S)"
  mkdir -p "$OUT/$NAME"
  "$BIN" --runs-per-plan 16 --seed 61444 --trainer nn --no-fingerprint \
    --model "$MODEL" --csv "$OUT/$NAME/games.csv" "$@" > "$OUT/$NAME/stdout.log" 2>&1
  tail -7 "$OUT/$NAME/stdout.log"
}
GEN2=(--space-version gen2_v1 --plans-file scripts/collect/formal2048_0914/holdout.json --run-offset 240000)
GEN1=(--run-offset 241000)
run gen2_A_1024 saved_models/arms/ens_G2mix1024_g123.onnx "${GEN2[@]}"
run gen2_B_2048 saved_models/arms/ens_G2mix_g123.onnx     "${GEN2[@]}"
run gen1_A_1024 saved_models/arms/ens_G2mix1024_g123.onnx "${GEN1[@]}"
run gen1_B_2048 saved_models/arms/ens_G2mix_g123.onnx     "${GEN1[@]}"
echo BUDGET_BENCH_DONE $(date +%H:%M:%S)
