#!/usr/bin/env bash
# 新教师 4096 A/B 三臂闭环（计划 §6.2 第一阶段，无搜索）。
# 预登记：logs/newteacher4096_ab_closedloop_0916/preregistration.md
# 冻结输入：logs/newteacher4096_ab_closedloop_0916/frozen_inputs.json
#
# 三臂只换 --model 一个参数；同一个现场重建的 release 二进制、同一份生效配置、
# 纯网络直接决策、canonical、自选比赛守门保持打开、--no-fingerprint。
# 世界号段：主面板 260000–260015，gen1 回归 261000–261007，均为未占用新号段。
set -e
OUT=logs/newteacher4096_ab_closedloop_0916
BIN=./target/release/ramen_space_bench.exe

ARMS=(
  "G2mix:saved_models/arms/ens_G2mix_g123.onnx"
  "AllHistory:saved_models/arms/ens_NT4096_AllHistory_g123.onnx"
  "PostPT:saved_models/arms/ens_NT4096_PostPT_g123.onnx"
)

run_panel() {  # $1=面板名  其余=bench 参数
  local PANEL="$1"; shift
  for ENTRY in "${ARMS[@]}"; do
    local NAME=${ENTRY%%:*} MODEL=${ENTRY##*:}
    local DIR="$OUT/$PANEL/$NAME"
    # 已有产物保护：不覆盖、不续跑，要重跑先自行移走旧目录
    if [ -e "$DIR/games.csv" ]; then
      echo "已有结果，停下处理，不覆盖：$DIR/games.csv" >&2
      exit 3
    fi
    mkdir -p "$DIR"
    echo "=== $PANEL / $NAME  $(date +%H:%M:%S)"
    "$BIN" "$@" --trainer nn --no-fingerprint --seed 61444 \
      --model "$MODEL" --csv "$DIR/games.csv" > "$DIR/stdout.log" 2>&1
    tail -9 "$DIR/stdout.log"
  done
}

run_panel main_holdout250 \
  --space-version gen2_v1 \
  --plans-file scripts/collect/formal2048_0914/holdout.json \
  --runs-per-plan 16 --run-offset 260000

run_panel gen1_regression525 \
  --runs-per-plan 8 --run-offset 261000

echo CLOSEDLOOP_DONE $(date +%H:%M:%S)
