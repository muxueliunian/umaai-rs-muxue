#!/usr/bin/env bash
# 第二轮：A1024 全部数据 + npy_n1024（ens_A1024 roll-in, search_n=1024）× init_seed 1,2,3
# 配方逐项照搬 scratch_arm.sh 的 A1024 臂，只多一组 --data/--labels
set -e
mkdir -p logs/arms
for SEED in 1 2 3; do
  D="target/arm_R2_seed${SEED}"
  if [ -f "$D/step_020000.pt" ]; then echo "skip R2/$SEED"; continue; fi
  echo "=== R2 seed$SEED  $(date +%H:%M:%S)"
  python scripts/ramen_nn/train.py \
    --data training_data/npy_v6ck         --labels training_data/labels_v6 \
    --data training_data/npy_ood_half101  --labels training_data/labels_ood_half101 \
    --data training_data/npy_dagger_c     --labels training_data/labels_dagger_c \
    --data training_data/npy_dagger_d     --labels training_data/labels_dagger_d \
    --data training_data/npy_n4096_w1024  --labels training_data/labels_n4096_w1024 \
    --data training_data/npy_n1024        --labels training_data/labels_n1024 \
    --output-dir "$D" \
    --frozen-constants target/dagger_d_seed1/run.json \
    --seed 20260830 --split-seed 20260830 --init-seed "$SEED" \
    --batch-size 256 --lr 5e-4 --head-lr 5e-4 --weight-decay 2e-5 \
    --lr-schedule cosine --lr-warmup-steps 300 --lr-final-factor 0.02 \
    --max-steps 20000 --no-early-stop \
    --validation-fraction 0.1 --split-by combo \
    --token-dim 96 --heads 4 --encoder-blocks 2 --mlp-width 256 --mlp-blocks 2 \
    --dropout 0.08 --attention-kind simple \
    --eval-columns 0 384 --checkpoint-steps 20000 \
    > "logs/arms/R2_seed${SEED}.log" 2>&1
  echo "    done $(date +%H:%M:%S)"
done
echo ALL_DONE
