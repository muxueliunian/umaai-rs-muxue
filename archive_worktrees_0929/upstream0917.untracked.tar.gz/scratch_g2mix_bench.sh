#!/usr/bin/env bash
# 闭环对照：基线 ens_R4_g123 vs 候选 ens_G2mix_g123，纯网络决策、不做搜索。
#
# 面板 = holdout.json 的 250 个最终留出组合（本轮训练零样本），每组合 8 个世界，
# 每侧 2000 局。两侧逐 (计划, 局号) 配对：基种子同为 61444，世界由
# derive_seed(61444 + plan_index * 1000003, [run_idx]) 决定，plan_index 保留
# gen2_v1 空间里的原始下标，因此两侧世界逐值相同。
#
# 两侧共用同一个二进制、同一份生效游戏配置（bin 内强制 ramen_region_strategy=all）、
# 同一套硬守门（不加 --no-race-shield）与同一个 SpecialSelect 口径（canonical）。
# --no-fingerprint：本轮口径禁止计算任何内容指纹，身份改记生效配置与计划下标原文。
set -e
OUT=logs/gen2_bench_0914
BIN=./target/release/ramen_space_bench.exe
COMMON=(--space-version gen2_v1
        --plans-file scripts/collect/formal2048_0914/holdout.json
        --runs-per-plan 8 --run-offset 210000 --seed 61444
        --trainer nn --no-fingerprint)
mkdir -p "$OUT"
for ARM in "A_r4g123:saved_models/arms/ens_R4_g123.onnx" "B_g2mix:saved_models/arms/ens_G2mix_g123.onnx"; do
  NAME=${ARM%%:*}
  MODEL=${ARM##*:}
  echo "=== $NAME  $(date +%H:%M:%S)"
  mkdir -p "$OUT/$NAME"
  "$BIN" "${COMMON[@]}" --model "$MODEL" --csv "$OUT/$NAME/games.csv" > "$OUT/$NAME/stdout.log" 2>&1
  tail -12 "$OUT/$NAME/stdout.log"
done
echo BENCH_DONE $(date +%H:%M:%S)
