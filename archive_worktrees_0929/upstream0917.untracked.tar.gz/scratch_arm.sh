#!/usr/bin/env bash
# 四臂对照训练：A0 / A512 / A1024 / A4096 × init_seed 1,2,3
set -e
ARM="$1"; SEED="$2"
BASE=(
  --data training_data/npy_v6ck        --labels training_data/labels_v6
  --data training_data/npy_ood_half101 --labels training_data/labels_ood_half101
  --data training_data/npy_dagger_c    --labels training_data/labels_dagger_c
  --data training_data/npy_dagger_d    --labels training_data/labels_dagger_d
)
EXTRA=()
case "$ARM" in
  A0) ;;
  A512)  EXTRA=(--data training_data/npy_n4096_w512  --labels training_data/labels_n4096_w512);;
  A1024) EXTRA=(--data training_data/npy_n4096_w1024 --labels training_data/labels_n4096_w1024);;
  A4096) EXTRA=(--data training_data/npy_n4096_w4096 --labels training_data/labels_n4096_w4096);;
  *) echo "未知臂 $ARM"; exit 1;;
esac
python scripts/ramen_nn/train.py \
  "${BASE[@]}" "${EXTRA[@]}" \
  --output-dir "target/arm_${ARM}_seed${SEED}" \
  --frozen-constants target/dagger_d_seed1/run.json \
  --seed 20260830 --split-seed 20260830 --init-seed "$SEED" \
  --batch-size 256 --lr 5e-4 --head-lr 5e-4 --weight-decay 2e-5 \
  --lr-schedule cosine --lr-warmup-steps 300 --lr-final-factor 0.02 \
  --max-steps 20000 --no-early-stop \
  --validation-fraction 0.1 --split-by combo \
  --token-dim 96 --heads 4 --encoder-blocks 2 --mlp-width 256 --mlp-blocks 2 \
  --dropout 0.08 --attention-kind simple \
  --eval-columns 0 384 --checkpoint-steps 20000
