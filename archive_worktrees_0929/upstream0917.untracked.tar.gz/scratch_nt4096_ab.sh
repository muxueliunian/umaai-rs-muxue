#!/usr/bin/env bash
# 新教师 4096 批 A/B：AllHistory / PostPT 两个数据配方，各三个初始化成员，固定 30000 步。
#
# 与 G2mix（scratch_g2mix.sh）逐项相同的部分：结构 96/4/2/256×2/0.08、优化设置
# （batch 256、lr/head_lr 5e-4、weight_decay 2e-5、cosine warmup 300、末端 0.02）、
# 预算 30000 optimizer steps、--no-early-stop、冻结常量 target/dagger_d_seed1/run.json、
# 划分清单 target/gen2_train_0914/dev_validation_combos.json、初始化种子 1/2/3。
#
# 本轮新增：
#   * 新教师 4096 的 16 个导出目录 + 新标签 training_data/labels_newteacher4096_0914；
#   * r4roll / r4roll2 两批（G2mix 未使用），外挂由实际采样计划补出的组合字段；
#   * 两个数据臂：ALL = 全部历史并集 + 新批；POST = 仅修复后规则语料 + 新批。
# ❗不使用 --resume；不加 --train-repeat；结构参数全部显式传入（避免 for_dataset 自动改模型）。
#
# 用法：bash scratch_nt4096_ab.sh <ALL|POST> <init-seed> [额外参数...]
set -e
ARM="$1"
SEED="$2"
shift 2

NEW_ROOT=training_data/newteacher4096_0914
NEW_LABELS=training_data/labels_newteacher4096_0914
G2_ROOT=target/acceptance_gen2_0914/full/npy/npy
G2_LABELS=training_data/labels_gen2f2048

ARGS=()

add_backfilled() {  # $1=npy 目录名  $2=标签目录名
  local NPY="training_data/npy_$1"
  ARGS+=(--data "$NPY" --labels "training_data/labels_$2")
  ARGS+=(--combo-fields "$NPY" "training_data/combo_fields_backfill/npy_$1.npy")
}

if [ "$ARM" = "ALL" ]; then
  OUT="target/arm_NT4096_AllHistory_seed${SEED}"
  # A 独有的旧规则四批（吃面 PT 延后修复之前）
  add_backfilled v6ck v6
  add_backfilled ood_half101 ood_half101
  add_backfilled dagger_c dagger_c
  add_backfilled dagger_d dagger_d
elif [ "$ARM" = "POST" ]; then
  OUT="target/arm_NT4096_PostPT_seed${SEED}"
else
  echo "第一个参数必须是 ALL 或 POST" >&2
  exit 2
fi

# 已有产物保护：本脚本只用于从零开训，绝不覆盖或续跑已交付的成员目录。
# 要重训请先自行改名/移走旧目录，脚本不代为删除。
if [ -e "$OUT" ]; then
  echo "输出目录已存在，停下处理，不覆盖：$OUT" >&2
  exit 3
fi
for A in "$@"; do
  case "$A" in
    --output-dir|--output-dir=*|--resume|--resume=*)
      echo "额外参数不允许包含 $A：会绕开已有产物保护或改成续跑" >&2
      exit 4
      ;;
  esac
done

# 两臂共有：修复后规则的旧目录
add_backfilled n4096_w1024 n4096_w1024
add_backfilled n1024 n1024
add_backfilled r2roll r2roll
add_backfilled r3roll r3roll
add_backfilled r4roll r4roll
add_backfilled r4roll2 r4roll2

# 两臂共有：gen2 正式 2048 的 16 个目录
for P in "$G2_ROOT"/*/; do
  NAME=$(basename "$P")
  ARGS+=(--data "${P%/}" --labels "$G2_LABELS/$NAME")
done

# 两臂共有：新教师 4096 的 16 个目录
for P in "$NEW_ROOT"/*/; do
  NAME=$(basename "$P")
  ARGS+=(--data "${P%/}" --labels "$NEW_LABELS/$NAME")
done

python -u scripts/ramen_nn/train.py \
  "${ARGS[@]}" \
  --validation-combos target/gen2_train_0914/dev_validation_combos.json \
  --output-dir "$OUT" \
  --frozen-constants target/dagger_d_seed1/run.json \
  --seed 20260830 --split-seed 20260830 --init-seed "$SEED" \
  --batch-size 256 --lr 5e-4 --head-lr 5e-4 --weight-decay 2e-5 \
  --lr-schedule cosine --lr-warmup-steps 300 --lr-final-factor 0.02 \
  --max-steps 30000 --no-early-stop \
  --token-dim 96 --heads 4 --encoder-blocks 2 --mlp-width 256 --mlp-blocks 2 \
  --dropout 0.08 --attention-kind simple \
  --eval-columns 0 384 --checkpoint-steps 30000 \
  "$@"
