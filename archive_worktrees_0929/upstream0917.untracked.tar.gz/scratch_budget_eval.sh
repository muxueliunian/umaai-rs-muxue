#!/usr/bin/env bash
# 预算对照的开发集诊断：两臂都在**同一份参考标签**（2048 列的数据与标签）上评，
# 1024 臂不对着自己的标签打分，否则「谁的标签更接近自己」会混进指标。
# 划分同为 dev_validation_combos.json。仅作辅助诊断，不用来挑 checkpoint。
set -e
OUT=logs/gen2_budget_0914/devset
NEW_ROOT=target/acceptance_gen2_0914/full/npy/npy
NEW_LABELS=training_data/labels_gen2f2048
mkdir -p "$OUT"

ARGS=()
for D in v6ck:v6 ood_half101:ood_half101 dagger_c:dagger_c dagger_d:dagger_d \
         n4096_w1024:n4096_w1024 n1024:n1024 r2roll:r2roll r3roll:r3roll; do
  NPY="training_data/npy_${D%%:*}"
  ARGS+=(--data "$NPY" --labels "training_data/labels_${D##*:}")
  ARGS+=(--combo-fields "$NPY" "training_data/combo_fields_backfill/npy_${D%%:*}.npy")
done
for P in "$NEW_ROOT"/*/; do
  ARGS+=(--data "${P%/}" --labels "$NEW_LABELS/$(basename "$P")")
done

for ARM in G2mix G2mix1024; do
  for SEED in 1 2 3; do
    CK="target/arm_${ARM}_seed${SEED}/step_030000.pt"
    echo "=== $ARM seed$SEED"
    python scripts/ramen_nn/eval.py "${ARGS[@]}" \
      --validation-combos target/gen2_train_0914/dev_validation_combos.json \
      --checkpoint "$CK" --split validation \
      > "$OUT/${ARM}_seed${SEED}.json" 2>&1
  done
done
echo EVAL_DONE
