#!/usr/bin/env bash
set -e
mkdir -p logs/arms
for ARM in A0 A512 A1024 A4096; do
  for SEED in 1 2 3; do
    D="target/arm_${ARM}_seed${SEED}"
    if [ -f "$D/step_020000.pt" ]; then echo "skip $ARM/$SEED"; continue; fi
    echo "=== $ARM seed$SEED  $(date +%H:%M:%S)"
    bash scratch_arm.sh "$ARM" "$SEED" > "logs/arms/${ARM}_seed${SEED}.log" 2>&1
    echo "    done $(date +%H:%M:%S)"
  done
done
echo ALL_DONE
