"""新教师 4096 A/B：三个集成在同一份 B 开发验证引用上的离线对照。

三个候选各由三个成员的平均 logit 构成（与 `export_ensemble_onnx.py` 同一规则），
**一个集成只算一个候选**，不把三个成员当三次独立实验。

口径：
- 主对照集 = B 的开发验证引用；次对照集 = 其中新 4096 批的子集。三个模型用**同一份**引用。
- regret 是**均值口径**（`cand_mean`，全列），与 rf1.4 的 utility regret 不是同一件事，本脚本不产出后者。
- value 用各模型自己的归一化常数反归一化后，在原始分数量纲比较。
- 地区按 turn 2 / 23 / 47 精确分到 Y1 / Y2 / Y3（实测 RegionSelect 只在这三个回合发生）。
"""

from __future__ import annotations

import argparse
import json
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np
import torch

sys.path.insert(0, str(Path(__file__).resolve().parent / "scripts" / "ramen_nn"))

from data import NpyShard, ValueNormalization, load_shards, split_refs_by_combos  # noqa: E402
from eval import STAGE_NAMES, select_candidate  # noqa: E402
from export_ensemble_onnx import EnsembleNetwork  # noqa: E402
from model import CHOICE_DIM, POLICY_DIM, model_from_checkpoint  # noqa: E402

REGION_YEAR = {2: "Y1", 23: "Y2", 47: "Y3"}

BACKFILL = {
    "training_data/npy_n4096_w1024": "training_data/combo_fields_backfill/npy_n4096_w1024.npy",
    "training_data/npy_n1024": "training_data/combo_fields_backfill/npy_n1024.npy",
    "training_data/npy_r2roll": "training_data/combo_fields_backfill/npy_r2roll.npy",
    "training_data/npy_r3roll": "training_data/combo_fields_backfill/npy_r3roll.npy",
    "training_data/npy_r4roll": "training_data/combo_fields_backfill/npy_r4roll.npy",
    "training_data/npy_r4roll2": "training_data/combo_fields_backfill/npy_r4roll2.npy",
}
OLD_LABELS = {
    "training_data/npy_n4096_w1024": "training_data/labels_n4096_w1024",
    "training_data/npy_n1024": "training_data/labels_n1024",
    "training_data/npy_r2roll": "training_data/labels_r2roll",
    "training_data/npy_r3roll": "training_data/labels_r3roll",
    "training_data/npy_r4roll": "training_data/labels_r4roll",
    "training_data/npy_r4roll2": "training_data/labels_r4roll2",
}


def build_b_shards() -> tuple[list[NpyShard], list[Path], set[int]]:
    """B 组的全部分片；返回分片、数据目录列表与「新 4096 批」的分片下标集合。"""

    data_dirs, label_dirs, combo = [], [], {}
    for d, cf in BACKFILL.items():
        data_dirs.append(Path(d))
        label_dirs.append(Path(OLD_LABELS[d]))
        combo[Path(d)] = Path(cf)
    for p in sorted(Path("target/acceptance_gen2_0914/full/npy/npy").iterdir()):
        data_dirs.append(p)
        label_dirs.append(Path("training_data/labels_gen2f2048") / p.name)
    new_start = len(data_dirs)
    for p in sorted(q for q in Path("training_data/newteacher4096_0914").iterdir() if q.is_dir()):
        data_dirs.append(p)
        label_dirs.append(Path("training_data/labels_newteacher4096_0914") / p.name)
    shards = load_shards(data_dirs, label_dirs, combo)
    return shards, data_dirs, set(range(new_start, len(data_dirs)))


def shape_lookup() -> dict[tuple[int, ...], str]:
    """组合标准字段 → 构成名。来源是实际采样计划，不反推。"""

    table: dict[tuple[int, ...], str] = {}
    plans = json.loads(Path("scripts/collect/formal2048_0914/plans.json").read_text(encoding="utf-8"))
    shapes = json.loads(Path("target/acceptance_gen2_0914/full/npy/npy/general_s1_1789320627243552018/meta.json")
                        .read_text(encoding="utf-8"))["space"]["shapes"]
    for p in plans:
        table[tuple(int(v) for v in p["fields"])] = shapes[int(p["shape"])]["name"]
    for line in Path("target/gen2_train_0914/plan_dump.txt").read_text(encoding="utf-8").splitlines():
        parts = line.split()
        if len(parts) >= 5 and parts[0].endswith("PLAN"):
            uma = int(parts[2])
            deck = sorted(int(v) for v in parts[3].split(","))
            table.setdefault(tuple([uma, *deck]), parts[4])
    return table


class Acc:
    """一个分组的可加统计。"""

    def __init__(self) -> None:
        self.n = 0
        self.top1 = 0
        self.regret = 0.0
        self.vabs = np.zeros(3, dtype=np.float64)
        self.invalid = 0
        self.slots: set[int] = set()

    def add(self, hit, regret, vabs, invalid, slot):
        self.n += 1
        self.top1 += int(hit)
        self.regret += float(regret)
        self.vabs += vabs
        self.invalid += int(invalid)
        if slot is not None:
            self.slots.add(int(slot))

    def report(self):
        if self.n == 0:
            return {"samples": 0, "top1_accuracy": None, "expected_regret_mean_scale": None,
                    "value_mae": None, "invalid_region_combo": 0, "distinct_chosen_slots": 0}
        return {"samples": self.n, "top1_accuracy": self.top1 / self.n,
                "expected_regret_mean_scale": self.regret / self.n,
                "value_mae": (self.vabs / self.n).tolist(),
                "invalid_region_combo": self.invalid,
                "distinct_chosen_slots": len(self.slots)}


@torch.inference_mode()
def evaluate(models: list[torch.nn.Module], norms: list[ValueNormalization], shards, refs,
             device, shapes, batch_size=1024):
    """一次前向遍历，给出总体与各分组统计。"""

    ens = EnsembleNetwork(models, [list(n.center) for n in norms], [list(n.scale) for n in norms]).to(device).eval()
    base = norms[0]
    center = np.asarray(base.center, dtype=np.float64)
    scale = np.asarray(base.scale, dtype=np.float64)

    groups = {"overall": Acc()}
    by = {k: defaultdict(Acc) for k in ("stage", "region_year", "uma", "shape")}
    label_slots: dict[str, set] = defaultdict(set)

    for lo in range(0, len(refs), batch_size):
        chunk = refs[lo:lo + batch_size]
        x = torch.from_numpy(np.stack([np.asarray(shards[int(si)].x[int(li)], dtype=np.float32) for si, li in chunk])).to(device)
        out = ens(x).cpu().numpy().astype(np.float64)
        logits = out[:, :POLICY_DIM]
        value_raw = out[:, POLICY_DIM + CHOICE_DIM:] * scale + center
        for row, (si, li) in enumerate(chunk):
            si, li = int(si), int(li)
            sh = shards[si]
            b, e = int(sh.cand_ptr[li]), int(sh.cand_ptr[li + 1])
            means = np.asarray(sh.cand_mean[b:e], dtype=np.float64)
            sel, invalid = select_candidate(logits[row], sh, li)
            best, chosen = float(means.max()), float(means[sel])
            hit = bool(np.isclose(chosen, best, rtol=0.0, atol=1e-4))
            vabs = np.abs(value_raw[row] - np.asarray(sh.value_target[li], dtype=np.float64))
            stage = int(sh.stage[li])
            turn = int(sh.turn[li])
            slot = int(np.asarray(sh.cand_slots[b + sel])[0]) if stage != 4 else None
            fields = tuple(int(v) for v in np.asarray(sh.combo_fields[li]))
            tgt_slot = int(np.argmax(np.asarray(sh.policy_target[li]))) if stage != 4 else None
            for acc in (groups["overall"], by["stage"][STAGE_NAMES[stage]],
                        by["uma"][str(fields[0])], by["shape"][shapes.get(fields, "未知构成")]):
                acc.add(hit, best - chosen, vabs, invalid, slot)
            if stage == 4:
                by["region_year"][REGION_YEAR.get(turn, "其他turn%d" % turn)].add(hit, best - chosen, vabs, invalid, None)
            if tgt_slot is not None:
                label_slots[STAGE_NAMES[stage]].add(tgt_slot)

    report = {"overall": groups["overall"].report()}
    for key in ("stage", "region_year", "uma", "shape"):
        report[key] = {k: v.report() for k, v in sorted(by[key].items())}
    report["label_distinct_slots_by_stage"] = {k: len(v) for k, v in sorted(label_slots.items())}
    return report


def main() -> None:
    ap = argparse.ArgumentParser(description="三个集成在同一份 B 开发验证引用上的离线对照")
    ap.add_argument("--out", type=Path, required=True)
    ap.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    ap.add_argument("--batch-size", type=int, default=1024)
    ap.add_argument("--only", action="append", help="只评估指定的臂名；可重复。默认三个全评")
    args = ap.parse_args()

    device = torch.device(args.device)
    shards, data_dirs, new_idx = build_b_shards()
    combos = json.loads(Path("target/gen2_train_0914/dev_validation_combos.json").read_text(encoding="utf-8"))["combos"]
    _, validation = split_refs_by_combos(shards, combos)
    new_mask = np.asarray([int(si) in new_idx for si, _ in validation])
    subsets = {"B_dev_validation_all": validation, "new4096_subset": validation[new_mask]}
    print("验证引用：全量 %d 条，新批子集 %d 条" % (len(validation), int(new_mask.sum())), flush=True)

    shapes = shape_lookup()
    arms = {
        "G2mix": ["target/arm_G2mix_seed%d/step_030000.pt" % s for s in (1, 2, 3)],
        "NT4096_AllHistory": ["target/arm_NT4096_AllHistory_seed%d/step_030000.pt" % s for s in (1, 2, 3)],
        "NT4096_PostPT": ["target/arm_NT4096_PostPT_seed%d/step_030000.pt" % s for s in (1, 2, 3)],
    }
    result = {"refs": {k: int(len(v)) for k, v in subsets.items()},
              "validation_combos": "target/gen2_train_0914/dev_validation_combos.json",
              "regret_口径": "均值口径（cand_mean 全列）；不是 rf1.4 utility regret",
              "集成规则": "policy/choice 取算术平均 logit；value 各自反归一化后平均（本轮三成员常量相同，重归一化为恒等）",
              "arms": {}}
    for name, paths in arms.items():
        if args.only and name not in args.only:
            continue
        cks = [torch.load(p, map_location="cpu", weights_only=False) for p in paths]
        models = [model_from_checkpoint(c, device) for c in cks]
        norms = [ValueNormalization.from_dict(c["value_normalization"]) for c in cks]
        entry = {"members": paths,
                 "value_normalization": [n.to_dict() for n in norms],
                 "members_share_constants": all(n.to_dict() == norms[0].to_dict() for n in norms)}
        for sub, refs in subsets.items():
            entry[sub] = evaluate(models, norms, shards, refs, device, shapes, args.batch_size)
            o = entry[sub]["overall"]
            print("%-20s %-22s n=%5d top1=%.4f regret=%8.2f vmae=%s" %
                  (name, sub, o["samples"], o["top1_accuracy"], o["expected_regret_mean_scale"],
                   [round(v, 1) for v in o["value_mae"]]), flush=True)
        result["arms"][name] = entry
        del models

    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(result, ensure_ascii=False, indent=1), encoding="utf-8")
    print("写出", args.out, flush=True)


if __name__ == "__main__":
    main()
