#!/usr/bin/env bash
# 马娘 113101 局部退步复核：gen1 空间点名 85 个组合 × 64 局，全新世界 230000–230063。
# 预登记见 logs/uma113101_recheck_0914/preregistration.md。
set -e
OUT=logs/uma113101_recheck_0914
BIN=./target/release/ramen_space_bench.exe
COMMON=(--plans-file "$OUT/plans_113101.json" --runs-per-plan 64 --run-offset 230000
        --seed 61444 --trainer nn --no-fingerprint)
for ARM in "A_r4g123:saved_models/arms/ens_R4_g123.onnx" "B_g2mix:saved_models/arms/ens_G2mix_g123.onnx"; do
  NAME=${ARM%%:*}; MODEL=${ARM##*:}
  echo "=== $NAME  $(date +%H:%M:%S)"
  mkdir -p "$OUT/$NAME"
  "$BIN" "${COMMON[@]}" --model "$MODEL" --csv "$OUT/$NAME/games.csv" > "$OUT/$NAME/stdout.log" 2>&1
  tail -8 "$OUT/$NAME/stdout.log"
done
echo RECHECK_DONE $(date +%H:%M:%S)
