#!/usr/bin/env bash
set -e
mkdir -p logs/gen2_budget_0914
PIDS=()
for SEED in 1 2 3; do
  D="target/arm_G2mix1024_seed${SEED}"
  if [ -f "$D/step_030000.pt" ]; then echo "skip seed$SEED"; continue; fi
  echo "=== G2mix1024 seed$SEED 启动 $(date +%H:%M:%S)"
  bash scratch_g2mix1024.sh "$SEED" > "logs/gen2_budget_0914/train_seed${SEED}.log" 2>&1 &
  PIDS+=($!)
done
for P in "${PIDS[@]}"; do wait "$P"; done
echo TRAIN1024_DONE $(date +%H:%M:%S)
