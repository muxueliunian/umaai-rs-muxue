#!/usr/bin/env bash
# 开发集诊断：在同一份划分（dev_validation_combos.json）上，把 R4 与 G2mix 的
# 三个成员各评一遍。仅作辅助诊断，不用来挑 checkpoint、不参与结论。
#
# 说明：该开发集对**两侧都是未见组合**——58 个旧组合本就是 R4 当年的留出，
# 331 个新组合来自 gen2 空间，R4 完全没有 gen2 数据。
set -e
OUT=logs/gen2_train_0914/devset
NEW_ROOT=target/acceptance_gen2_0914/full/npy/npy
NEW_LABELS=training_data/labels_gen2f2048
mkdir -p "$OUT"

ARGS=()
for D in v6ck:v6 ood_half101:ood_half101 dagger_c:dagger_c dagger_d:dagger_d \
         n4096_w1024:n4096_w1024 n1024:n1024 r2roll:r2roll r3roll:r3roll; do
  NPY="training_data/npy_${D%%:*}"
  ARGS+=(--data "$NPY" --labels "training_data/labels_${D##*:}")
  ARGS+=(--combo-fields "$NPY" "training_data/combo_fields_backfill/npy_${D%%:*}.npy")
done
for P in "$NEW_ROOT"/*/; do
  ARGS+=(--data "${P%/}" --labels "$NEW_LABELS/$(basename "$P")")
done

for ARM in R4 G2mix; do
  for SEED in 1 2 3; do
    CK="target/arm_${ARM}_seed${SEED}/step_030000.pt"
    echo "=== $ARM seed$SEED"
    python scripts/ramen_nn/eval.py "${ARGS[@]}" \
      --validation-combos target/gen2_train_0914/dev_validation_combos.json \
      --checkpoint "$CK" --split validation \
      > "$OUT/${ARM}_seed${SEED}.json" 2>&1
  done
done
echo EVAL_DONE
